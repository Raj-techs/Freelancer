import React, { useEffect } from 'react'
import Nav from '../components/Nav'
import { workersData } from '../data/works'
import { Link } from 'react-router-dom';
import axios from 'axios'

const Myworks = () => {
  let fiveWorkers = workersData.slice(0,5);

  // let dbData = axios.get('http://localhost:5000/users/allusers').then(res=>console.log(res)).catch(bad=>console.log("sorry for bad api"))
  return (
    <>
      <div className='myworks-heading'>
        <Link to='/'><span class="material-symbols-outlined" style={{fontSize:"50px",marginTop:"18px"}}>
          arrow_back
        </span></Link>
        <p>My works </p><span className='workcount'>5</span>
      </div>
      <div className="myworks-container">
        {fiveWorkers.map(items=>{
          return(<div className="mywork-cards">
          <img src={items.img} alt=""  width={"40%"} height={"40%"} style={{borderRadius:"50%"}}/>
          <p>{items.name}</p>
          <div style={{ display: "flex", gap: "20px", fontSize: 20 }}>
                                        <div><i class="fa-solid fa-phone"></i></div>
                                        <div><i class="fa-solid fa-envelope"></i></div>
                                    </div>
          <h3>{items.work} - {items.rating}/-</h3>
          <p> DeadLine - {items.deadline}</p>
          <Link to={`/workerprofile/${items.id}`}>See More</Link>
        </div>)
        })}
        
       
      </div>
      <div>
        <h2>hello dbdata</h2>
        <div className="mywork-cards">
          <h2>{}</h2>
        </div>
      </div>
    </>
  )
}

export default Myworks
