import React from 'react'
import Nav from '../components/Nav'
import HomePoster from '../components/HomePoster'

const HomePg = () => {
  let navData ={    
    name1:"Add work",
    name2:"My Works"
  }
  return (
    <>
        <Nav data={navData} />
        <HomePoster/>
        <div className="bot">
        <abbr title="ChatBot"><i class="fa-solid fa-headset"></i></abbr>
        </div>
    </>
  )
}

export default HomePg
