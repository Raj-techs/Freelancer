import React, { useState, useSyncExternalStore } from 'react'
import {workersData} from '../data/works'
import { Link } from 'react-router-dom';
const Avail = () => {
    const [available,setAvailable]=useState(workersData);
    const [searchText,setSearchText]=useState("")
    const filterWorks = filterWork(available,searchText)

    function filterWork(available,searchKey){
        console.log(available);
        return available.filter(p=>{
            return p.work.toLowerCase().includes(searchKey)
        })
    }

    return (
        <>
            <div className="avail-container">
                <div className="avail-inner">
                    <div className="avail-head">
                        <button onClick={e=>setSearchText('assignment')}>Assignment</button>
                        <button onClick={e=>setSearchText('record')}>Record</button>
                        <button onClick={e=>setSearchText('notes')}>Notes</button>
                        <button onClick={e=>setSearchText('shots')}>Shots</button>
                        <button onClick={e=>setSearchText('webDev')}>WebDev</button>
                        <div className="outer-input">
                        <input type="text" style={{fontSize:"20px"}} onChange={(e)=>setSearchText(e.target.value)}/><i style={{fontSize:25,color:"black",marginTop:"6px"}} class="fa-solid fa-magnifying-glass"></i>
                        </div>
                    </div>
                    <div className='headings'>
                        <ul>
                            <li>Name</li>
                            <li>Contacts</li>
                            <li>Work</li>
                            <li>Closing_Time</li>
                            <li>Deadline</li>
                            <li>More</li>
                        </ul>
                    </div>
                    <div className="scroll-cards">
                    {
                    filterWorks.length>=0?  filterWorks.map(data => {
                            console.log(data);
                            return (

                            <div className='user-card'>
                                


                                    <div style={{ display: "flex" }}>
                                        <img src={data.img} width={45} height={45} alt="" style={{ borderRadius: "20px" }} />
                                        <h3 style={{ marginLeft: "10px", marginTop: "5px" }}>{data.name}</h3>
                                    </div>
                                    <div style={{ display: "flex", gap: "20px", fontSize: 20 }}>
                                        <div><i class="fa-solid fa-phone"></i></div>
                                        <div><i class="fa-solid fa-envelope"></i></div>
                                    </div>
                                    <div>
                                        <h3>{data.work}</h3>
                                    </div>
                                    <div>
                                        {data.closing_time}
                                    </div>
                                    <div>
                                        {data.deadline}
                                    </div>
                                    <button className='details'><Link to={`/workerprofile/${data.id}`} style={{color:"white",textDecoration:"none"}}>Details</Link></button>
                            </div>)
                        }):<div className='filter-not-found'></div>
                    }
                                </div>

                </div>
            </div>
        </>
    )
}

export default Avail
