import React from 'react'
import Nav from '../components/Nav'

const Notify = () => {
  return (
    <>
        <Nav/>
         
    </>
  )
}

export default Notify
