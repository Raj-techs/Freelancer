import React from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import SignUp from './pages/SignUp'
import HomePg from './pages/HomePg'
import Profile from './pages/Profile'
import Avail from './pages/Avail'
import Login from './pages/Login'
import WorkerProfile from './pages/WorkerProfile'
import Addwork from './pages/Addwork'
import Myworks from './pages/Myworks'
import History from './pages/History'

const App = () => {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<HomePg/>}/>
          <Route path='/signup' element={<SignUp/>}/>
          <Route path='/profile' element={<Profile/>}/>
          <Route path='/avail' element={<Avail/>}/>
          <Route path='/login' element={<Login/>}/>
          <Route path='/addwork' element={<Addwork/>}/>
          <Route path='/myworks' element={<Myworks/>}/>
          <Route path='/history' element={<History/>}/>

          <Route path='/workerprofile/:id' element={<WorkerProfile/>}/>
        </Routes>
      </BrowserRouter>
    </>
  )
}

export default App
