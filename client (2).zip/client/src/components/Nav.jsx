import React from 'react'
import { Link } from 'react-router-dom'

const Nav = ({data}) => {
    return (
        <>
            <nav>
                <div className="logo">
                    <img width={100} src="https://e7.pngegg.com/pngimages/328/113/png-clipart-freelancer-freelance-marketplace-logo-job-graphic-designer-design-web-design-text.png" alt="" />
                </div>
                <div className="opts">
                    <ul>
                    <Link  to='/'><li>Home</li></Link>
                        <li>About</li>
                        
                        <Link to='/addwork'><li>{data.name1}</li></Link>
                        <Link to='/avail'><li>Avail</li></Link>
                        <Link to='/myworks'><li>My works</li></Link>
                        <Link to='/history'><li>History</li></Link>
                        <li>Blog</li>
                    </ul>
                </div>
                <div className="more">
                    {/* <i  className="fa-solid fa-magnifying-glass"></i> */}
                    <i style={{marginRight:"30px",marginTop:"2px"}} class="material-symbols-outlined">
notifications
</i>
                    {/* {data.name2 == "My Works" ? <Link to='/myworks'><button>{data.name2}</button> </Link>: null} */}
                    <button>Sign</button>
                    <Link to='/signup'><button>SignUp</button></Link>
                </div>
            </nav>
        </>
    )
}

export default Nav
