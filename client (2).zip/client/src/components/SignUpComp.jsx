import React, { useState } from 'react'
import Login from '../pages/Login'
import { Link } from 'react-router-dom'

const SignUpComp = () => {


    return (
        <>
            <div className="signup">
                <h1>Sign Up</h1>
                <p><Link to='/login'>Have an account (Login)</Link></p>

                <div>
                    <p>Looking for ?</p>
                    <div>
                        <button>Project</button>
                        <button>Designs</button>
                    </div>
                </div>

                <div>
                    <p>E-mail*</p>
                    <input type="text" />
                </div>
                <div>
                    <p>Password*</p>
                    <input type="text" />
                </div>
                <div>
                    <p>Confirm Password*</p>
                    <input type="text" />
                </div>

                <div style={{display:"flex"}}>

                    <div>
                        <p>
                            WhatsApp Number*
                        </p>
                        <input type="text" />
                    </div>

                    <div>
                        <p>
                            Mobile Number*
                        </p>
                        <input type="text" />
                    </div>

                    <div>
                        <p>
                            Year (Academic)*
                        </p>
                        <input type="text" />
                    </div>

                    <div>
                        <p>
                             PhonePay QR
                        </p>
                        <input type="file" />
                    </div>


                </div>
                <div>
                    <button>Illustration</button><button>Branding</button>
                </div>

                <div>
                    <button className='createA'>Create Account</button>
                </div>
            </div>
        </>
    )
}

export default SignUpComp
