import React, { useState } from 'react'
import { workersData } from '../data/works'
import Nav from '../components/Nav'
import { useParams } from 'react-router-dom'
const WorkerProfile = () => {
    const [chatting, setChatting] = useState(false);
    const [payment, setPayment] = useState(true)
    let { id } = useParams();
    let Worker = workersData.find(details => details.id === parseInt(id));
    let navData={
        name1:"Team"
    }
    return (
        <>
            <Nav data={navData}/>
            <div className="worker-profile">
                <div className="worker-img">
                    <img src={Worker.img} width={200} style={{ borderRadius: "50%" }} alt="" />
                    <h1> {Worker.name}</h1>
                    <p>{Worker.liked} Liked</p>
                    <p>Year : {Worker.year}</p>
                    <div className="worker-socialIcons" style={{ fontSize: "30px" }}>
                        <span><i class="fa-solid fa-location-dot" style={{ color: "green" }}></i> </span>
                        <span><i class="fa-brands fa-facebook" style={{ color: "blue" }}></i> </span>
                        <span><i class="fa-brands fa-linkedin" style={{ color: "blue" }}></i> </span>
                        <span><i class="fa-brands fa-twitter" style={{ color: "cyan" }}></i> </span>
                    </div>
                    <div className='rating'>
                        <span style={{ fontSize: "3em" }}>{Worker.rating}</span>
                        <div>
                            <p><i class="fa-regular fa-star"></i><i class="fa-regular fa-star"></i><i class="fa-regular fa-star"></i><i class="fa-regular fa-star"></i></p>
                            <p>104 views</p>
                        </div>
                    </div>
                </div>

                <div className="worker-work">
                    <div>
                        <h2>Work</h2>
                        <input type="text" value={Worker.work} />
                    </div>
                    <div>
                        <h2>References</h2>
                        <span style={{ display: 'flex', gap: 20 }}>
                            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/87/PDF_file_icon.svg/1200px-PDF_file_icon.svg.png" width={30} alt="" />
                            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/87/PDF_file_icon.svg/1200px-PDF_file_icon.svg.png" width={30} alt="" />
                            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/87/PDF_file_icon.svg/1200px-PDF_file_icon.svg.png" width={30} alt="" />
                        </span>
                    </div>
                    <div>
                        <h2>Description</h2>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eaque quas quam fugit vitae porro harum. Unde sequi dolor dolore distinctio saepe aliquam, autem, maxime quia quo, ea aspernatur voluptatem. Vero?</p>
                    </div>
                    <div style={{ display: 'flex', gap: 50 }}>
                        <span><h3>Closes : 2:00 PM </h3></span>
                        <span><h3>DeadLine : 24th May 2024 </h3></span>
                    </div>
                    <div>
                        <h2>Amount : 170/-</h2>
                        <p>Amount will be sent within 24 hrs (within One day) to your account balance</p>
                    </div>
                    <div>
                        <h2><i class="fa-regular fa-clock"></i> : 72:12:00 sec</h2>
                    </div>

                    <center><button className='confirm-btn' onClick={_=>alert(`Work Confirmed with ${Worker.name}`)}>Confirm</button></center>
                </div>
                <div className="worker-cAp">
                    <div className="worker-cAp-header">
                        <div onClick={() => { setChatting(true); setPayment(false) }}>Chatting</div>
                        <div onClick={() => { setPayment(true); setChatting(false) }}>Payment</div>
                    </div>
                    {chatting ? <ChattingDiv /> : <PaymentDiv />}
                </div>
            </div>
        </>
    )
}

const ChattingDiv = () => {
    const [chatdata,setChatdata]=useState([
        {id:1,chat:"hello worker"},
        {id:2,chat:"hello customer"},
        {id:3,chat:"i will do the work"},
    ])
    const [msg,setMsg]=useState("")

   

    return (
        <>
            <div className="scroll-msg-space">
                <div className="msg-space">
                    <div style={{ color: 'black', display: "flex", flexDirection: "column", gap: 50, justifyContent: "space-between" }}>
                        {chatdata.map(items=>{
                            return(<h4>{items.chat}</h4>)
                        })}
                    </div>
                </div>
            </div>
            <div className="msg-inputs">
                <input type="text" placeholder='Message' onChange={e=>setMsg(e.target.value)} />
                <i  style={{ fontSize: "1.3em", padding: "13px", borderRadius: '20px', backgroundColor: "blue" }} class="fa-regular fa-paper-plane"></i>
            </div>
        </>
    )
}

const PaymentDiv = () => {
    let { id } = useParams();
    let Worker = workersData.find(details => details.id === parseInt(id));
    return (
        <>
            <div className="paymentdiv">
                <center><h2 className="payment-heading">{Worker.name}</h2></center>
                <div className="payment-img"></div>
                <center className="payment-upi">UPI ID :{Worker.name}@okaxis</center>
            </div>
        </>
    )
}
export default WorkerProfile
